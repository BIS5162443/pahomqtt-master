# pahomqtt
This is a project to control the STM32F3 Discovery Development Board , by using MQTT over Node-Red
![screenshot from 2016-11-20 01-01-59](https://cloud.githubusercontent.com/assets/23266310/20457993/7e8ab50a-aebe-11e6-8a85-574a89c7ae54.png)
